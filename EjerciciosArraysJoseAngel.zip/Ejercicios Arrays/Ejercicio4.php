<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    $mes[] = "Pedro";
    $mes[] = "Ana";
    $mes[] = "34";
    $mes[] = "1";


    echo print_r($mes);

    ?>
</body>

</html>